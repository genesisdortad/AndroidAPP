package com.example.primeraapp;

import androidx.appcompat.app.AppCompatActivity;

import org.mariuszgromada.math.mxparser.*;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int contador=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Eventoteclado teclado = new Eventoteclado();
        EditText n_reseteo = (EditText)findViewById(R.id.valorreseteo);
        n_reseteo.setOnEditorActionListener(teclado);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        TextView resultado=(TextView)findViewById(R.id.valorcontador);
        resultado.setText(""+contador);
        Bundle datos = getIntent().getExtras();
        int numero1  = datos.getInt("d1");
        contador= numero1;
        mostrarResultado();
    }

    public void botonsumar(View j){
        contador++;
        mostrarResultado();
        }

    public void botonrestar(View j){
        if (contador<=0)
            contador = 0;
        else contador--;
        mostrarResultado();

    }

        public void bloqueo(View j){
            CheckBox pulsar = (CheckBox)findViewById(R.id.bloqueo);
            Button boton = (Button) findViewById(R.id.botonrestar);
            if (pulsar.isChecked()){
                boton.setEnabled(false);
            }else {
                boton.setEnabled(true);
            }

        }

    public void botonreseteo(View j){
        TextView numero_reseteo=(TextView) findViewById(R.id.valorreseteo);
        try{
            contador=Integer.parseInt(numero_reseteo.getText().toString());
             }catch (Exception e) {
            contador = 0;
        }
        mostrarResultado();
        numero_reseteo.setText("");
        /*Queremos que el  teclado desaparezca al terminar de introducir los datos*/
        InputMethodManager teclado = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        teclado.hideSoftInputFromWindow(numero_reseteo.getWindowToken(),0);


    }

    public void mostrarResultado(){
        TextView resultado=(TextView) findViewById(R.id.valorcontador);
        resultado.setText(Integer.toString(contador));

    }

   /* @Override
    public void onPause(){
        super.onPause();
        SharedPreferences datos = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor miEditor = datos.edit();
        miEditor.putInt("cuenta", contador);
        miEditor.apply();

    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences datos = PreferenceManager.getDefaultSharedPreferences(this);
        contador = datos.getInt("cuenta", 0);
        TextView resultado = (TextView) findViewById(R.id.valorcontador);
        resultado.setText(""+contador);
    }*/
    class Eventoteclado implements TextView.OnEditorActionListener {
        @Override
        public boolean onEditorAction(TextView j, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                botonreseteo(null);
            }
            return false;
        }
    }
}