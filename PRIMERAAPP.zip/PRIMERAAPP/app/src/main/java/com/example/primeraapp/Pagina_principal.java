package com.example.primeraapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Pagina_principal extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagina_principal);
        toolbar=(Toolbar)findViewById(R.id.menu_toolbar);
        setSupportActionBar(toolbar);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu mimenu){
        getMenuInflater().inflate(R.menu.menu_principal, mimenu);
        return true;
    }

    public void ejecutar_contador(View v){
        Intent i = new Intent(this, MainActivity.class);
        EditText valor = (EditText) findViewById(R.id.valorinicial);
        int v1 = Integer.parseInt(valor.getText().toString());
        i.putExtra("d1", v1);
        startActivity(i);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem opcion_menu){
        int id = opcion_menu.getItemId();
        if (id==R.id.contador_menu){ ejecutar_contador(null);
        return true; }
        if (id== R.id.calculadora_menu){ ejecutarCalculadora(null);
        return true; }
        if (id==R.id.juegos_menu){ ejecutarJuegos(null);
            return true; }
        return super.onOptionsItemSelected(opcion_menu);

    }


    public void ejecutarCalculadora(View v) {
        Intent i = new Intent(this, calculadora.class);
        startActivity(i);
    }

    public void ejecutarJuegos(View v){
        Intent i = new Intent(this, Juegos.class);
        startActivity(i);
    }

    public void SalirApp(View view){
        finish();
    }
}