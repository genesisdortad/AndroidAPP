package com.example.primeraapp;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Tresenraya extends AppCompatActivity {

    TextView textovictoria;
    Integer[] botones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tresenraya);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        textovictoria = (TextView) findViewById(R.id.textovictoria);
        textovictoria.setVisibility(View.INVISIBLE);

        botones = new Integer[]{
          R.id.b1, R.id.b2, R.id.b3,
          R.id.b4, R.id.b5, R.id.b6,
          R.id.b7, R.id.b8, R.id.b9,
        };


    }

    public void ponerFicha(View v){
        int numBoton = Arrays.asList(botones).indexOf(v.getId());
        v.setBackgroundResource();

    }


}
