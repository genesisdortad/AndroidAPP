package com.example.primeraapp;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.mariuszgromada.math.mxparser.*;


import androidx.appcompat.app.AppCompatActivity;

public class calculadora extends AppCompatActivity {


    private Button botonsuma;
    private Button botonresta, botonmultiplicar, botondivisor, botontotal, botonpunto, botonCE, botonAC;
    private Button botonelevar, boton9, boton8, boton7, boton6, boton5, boton4, boton3, boton2, boton1, boton0;
    private EditText display;
    private TextView display2;

    String operacion = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        display = findViewById(R.id.textpantalla);
        display2= findViewById(R.id.textpantalla2);
        display.setShowSoftInputOnFocus(false);

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getString(R.string.display).equals(display.getText().toString()))
                    display.setText("");
            }
        });


    }

    public void boton0(View view) {
        cargarTexto("0");
    }

    public void boton1(View view) {
        cargarTexto("1");
    }

    public void boton2(View view) {
        cargarTexto("2");
    }

    public void boton3(View view) {
        cargarTexto("3");
    }

    public void boton4(View view) {
        cargarTexto("4");
    }

    public void boton5(View view) {
        cargarTexto("5");
    }

    public void boton6(View view) {
        cargarTexto("6");
    }

    public void boton7(View view) {
        cargarTexto("7");
    }

    public void boton8(View view) {
        cargarTexto("8");

    }

    public void boton9(View view) {
        cargarTexto("9");
    }

    public void botonplus(View view) {
        cargarTexto("+");
    }

    public void botonminus(View view) {
        cargarTexto("-");

    }

    public void botonmultiplicar(View view) {
        cargarTexto("*");
    }

    public void botondividir(View view) {
        cargarTexto("÷");
    }

    public void botonparent(View view) {
        int cursorPos = display.getSelectionStart();
        int abrirPar = 0;
        int cerrarPar = 0;
        int textLen = display.getText().length();

        for (int i = 0; i < cursorPos; i++) {
            if (display.getText().toString().substring(i, i + 1).equals("(")) {
                abrirPar += 1;
            }//IF
            if (display.getText().toString().substring(i, i + 1).equals(")"))
                cerrarPar += 1;

        }//FOR

        if (abrirPar == cerrarPar || display.getText().toString().substring(textLen - 1, textLen).equals("(")) {
            cargarTexto("(");

        } else if (cerrarPar < abrirPar && !display.getText().toString().substring(textLen - 1, textLen).equals(")")) {
            cargarTexto(")");


        }//ELSE IF
        display.setSelection(cursorPos + 1);

    }//VOID

    public void botonAC(View view){
        display.setText("");
    }


    public void botonigual(View view){
        String userExp = display.getText().toString();

        userExp = userExp.replaceAll("÷", "/");
        userExp = userExp.replaceAll("×", "*");

        Expression exp = new Expression(userExp);

        String resultado = String.valueOf(exp.calculate());
        display.setText(resultado);
        display.setSelection(resultado.length());
        display2.setText(userExp+" =");





    }
    public void botonpunto(View view){
        cargarTexto(".");
    }

    public void cargarTexto(String agregar){
        String ant= display.getText().toString();
        int cursorPos = display.getSelectionStart();
        String izq = ant.substring(0, cursorPos);
        String derec = ant.substring(cursorPos);
        if(getString(R.string.display).equals(display.getText().toString())){
            display.setText(agregar);
            display.setSelection(cursorPos+1);
        }
        else{

            display.setText(String.format("%s%s%s", izq, agregar,derec));
            display.setSelection(cursorPos+1);

        }


    }



    public void botonCE (View view){
        int cursorPos = display.getSelectionStart();
        int textLen = display.getText().length();

            if (cursorPos !=0  && textLen != 0){
                SpannableStringBuilder selection = (SpannableStringBuilder)display.getText();
                selection.replace(cursorPos -1 , cursorPos, "");
                display.setText(selection);
                display.setSelection(cursorPos-1);


            }

    }
}
